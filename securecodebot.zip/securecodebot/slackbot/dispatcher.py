# -*- coding: utf-8 -*-

from __future__ import absolute_import
import logging
import re
import time
import traceback
from functools import wraps

import six
from slackbot.manager import PluginsManager
from slackbot.utils import WorkerPool
from slackbot import settings

logger = logging.getLogger(__name__)
ignored = []


class MessageDispatcher(object):
    def __init__(self, slackclient, plugins, errors_to):
        self._client = slackclient
        self._pool = WorkerPool(self.dispatch_msg)
        self._plugins = plugins
        self._errors_to = None
        if errors_to:
            self._errors_to = self._client.find_channel_by_name(errors_to)
            if not self._errors_to:
                raise ValueError(
                    'Could not find errors_to recipient {!r}'.format(
                        errors_to))

        alias_regex = ''
        if getattr(settings, 'ALIASES', None):
            logger.info('using aliases %s', settings.ALIASES)
            alias_regex = '|(?P<alias>{})'.format('|'.join([re.escape(s) for s in settings.ALIASES.split(',')]))

        self.AT_MESSAGE_MATCHER = re.compile(r'^(?:\<@(?P<atuser>\w+)\>:?|(?P<username>\w+):{}) ?(?P<text>.*)$'.format(alias_regex))

    def start(self):
        self._pool.start()

    def dispatch_msg(self, msg):
        category = msg[0]
        msg = msg[1]
        if not self._dispatch_msg_handler(category, msg):
            if category == u'respond_to':
                if not self._dispatch_msg_handler('default_reply', msg):
                    self._default_reply(msg)

    def _dispatch_msg_handler(self, category, msg):
        responded = False
        for func, args in self._plugins.get_plugins(category, msg.get('text', None)):
            if func:
                responded = True
                try:
                    func(Message(self._client, msg), *args)
                except:
                    logger.exception(
                        'failed to handle message %s with plugin "%s"',
                        msg['text'], func.__name__)
                    reply = u'[{}] I had a problem handling "{}"\n'.format(
                        func.__name__, msg['text'])
                    tb = u'```\n{}\n```'.format(traceback.format_exc())
                    if self._errors_to:
                        self._client.rtm_send_message(msg['channel'], reply)
                        self._client.rtm_send_message(self._errors_to,
                                                      '{}\n{}'.format(reply,
                                                                      tb))
                    else:
                        self._client.rtm_send_message(msg['channel'],
                                                      '{}\n{}'.format(reply,
                                                                      tb))
        return responded

    def _on_new_message(self, msg):
        # ignore edits
        subtype = msg.get('subtype', '')
        if subtype == u'message_changed':
            return

        botname = self._get_bot_name()
        try:
            msguser = self._client.users.get(msg['user'])
            username = msguser['name']
            print username
        except (KeyError, TypeError):
            if 'username' in msg:
                username = msg['username']
            else:
                return

        if username == botname or username == u'slackbot':
            return

        msg_respond_to = self.filter_text(msg)
        if msg_respond_to:
            self._pool.add_task(('respond_to', msg_respond_to))
        else:
            self._pool.add_task(('listen_to', msg))

    def _get_bot_id(self):
        return self._client.login_data['self']['id']

    def _get_bot_name(self):
        return self._client.login_data['self']['name']

    def filter_text(self, msg):
        full_text = msg.get('text', '') or ''
        channel = msg['channel']
        bot_name = self._get_bot_name()
        bot_id = self._get_bot_id()
        m = self.AT_MESSAGE_MATCHER.match(full_text)

        if channel[0] == 'C' or channel[0] == 'G':
            if not m:
                return

            matches = m.groupdict()

            atuser = matches.get('atuser')
            username = matches.get('username')
            text = matches.get('text')
            alias = matches.get('alias')

            if alias:
                atuser = bot_id

            if atuser != bot_id and username != bot_name:
                # a channel message at other user
                return

            logger.debug('got an AT message: %s', text)
            msg['text'] = text
        else:
            if m:
                msg['text'] = m.groupdict().get('text', None)
        return msg

    def loop(self):
        while True:
            events = self._client.rtm_read()
            for event in events:
                event_type = event.get('type')
                if event_type == 'message':
                    self._on_new_message(event)
                elif event_type in ['channel_created', 'channel_rename',
                                    'group_joined', 'group_rename',
                                    'im_created']:
                    channel = [event['channel']]
                    self._client.parse_channel_data(channel)
                elif event_type in ['team_join', 'user_change']:
                    user = [event['user']]
                    self._client.parse_user_data(user)
            time.sleep(1)

    def _default_reply(self, msg):
        default_reply = settings.DEFAULT_REPLY
        if default_reply is None:
            default_reply = [
                u'Bad command "{}", You can ask me one of the following '
                u'questions:\n'.format(
                    msg['text']),
            ]
            default_reply += [
                u'    • `{0}` {1}'.format(p.pattern, v.__doc__ or "")
                for p, v in
                six.iteritems(self._plugins.commands['respond_to'])]
            # pylint: disable=redefined-variable-type
            default_reply = u'\n'.join(default_reply)

        m = Message(self._client, msg)
        m.reply(default_reply)


def unicode_compact(func):
    """
    Make sure the first parameter of the decorated method to be a unicode
    object.
    """

    @wraps(func)
    def wrapped(self, text, *a, **kw):
        if not isinstance(text, six.text_type):
            text = text.decode('utf-8')
        return func(self, text, *a, **kw)

    return wrapped


class Message(object):
    def __init__(self, slackclient, body):
        self._client = slackclient
        self._body = body
        self._plugins = PluginsManager()
        self._admins = ["mharlo", "earno1", "jason.tripp"]

    def _get_user_id(self):
        if 'user' in self._body:
            return self._body['user']
        print self._client.find_user_by_name(self._body['username'])
        return self._client.find_user_by_name(self._body['username'])

    def _get_user_id_2(self, user):
        print self._client.find_user_by_name(user)
        return self._client.find_user_by_name(user)

    @unicode_compact
    def _gen_at_message(self, text):
        text = u'<@{}>: {}'.format(self._get_user_id(), text)
        return text

    @unicode_compact
    def gen_reply(self, text):
        chan = self._body['channel']
        print chan
        if chan.startswith('C') or chan.startswith('G'):
            return self._gen_at_message(text)
        else:
            return text

    @unicode_compact
    def reply_webapi(self, text, attachments=None, as_user=True):
        """
            Send a reply to the sender using Web API

            (This function supports formatted message
            when using a bot integration)
        """
        text = self.gen_reply(text)
        self.send_webapi(text, attachments=attachments, as_user=as_user)

    @unicode_compact
    def send_webapi(self, text, attachments=None, as_user=True, link_names=1):
        """
            Send a reply using Web API

            (This function supports formatted message
            when using a bot integration)
        """
        self._client.send_message(
            self._body['channel'],
            text,
            attachments=attachments,
            as_user=as_user)

    @unicode_compact
    def send_DM_webapi(self, text, attachments=None, as_user=True):
        self._client.send_message(
            self._get_user_id(),
            text,
            attachments=attachments,
            as_user=as_user)

    @unicode_compact
    def send_userDM_webapi(self, text, user, attachments=None, as_user=True):
        self._client.send_message(
            self._client.find_user_by_name(user),
            text,
            attachments=attachments,
            as_user=as_user)

    @unicode_compact
    def reply(self, text):
        text = self.gen_reply(text)
        self.send(text)

    @unicode_compact
    def send(self, text):
        self._client.rtm_send_message(self._body['channel'], text)

    @unicode_compact
    def sendDM(self, user, text):
        print self._get_user_id()
        self._client.rtm_send_message(self._get_user_id(), text)

    @unicode_compact
    def sendFileDM(self, user, fpath, fname, comment):
        if user == "GETUSER":
            user = self._get_user_id()
            self._client.upload_file(user, fname, fpath, comment)
        else:
            self._client.upload_file(self._client.find_user_by_name(user), fname, fpath, comment)

    @unicode_compact
    def sendFile(self, fpath, fname, comment):
        self._client.upload_file(self._client.get_channel(self._body['channel']), fname, fpath, comment)

    @unicode_compact
    def adminCheck(self, comment):
        logger.info(self._ignore)
        username = self._client.find_user_by_id(self._get_user_id())
        print "The username is '{0}'".format(username)
        admin = False
        for user in self._admins:
            print "'{0}' : '{1}'".format(user, username)
            if user == username:
                admin = True
        if admin:
            self._client.rtm_send_message(self._body['channel'], "I recognize your authority.")
        else:
            self._client.rtm_send_message(self._body['channel'], "I do not recognize your authority. Nice try")

    @unicode_compact
    def ignorecheck(self, comment):
        global ignored
        logger.info("Ignore Check")
        logger.info(ignored)
        username = self._client.find_user_by_id(self._get_user_id())
        logger.info("The username is '{0}'".format(username))
        ignore = False
        for user in ignored:
            logger.info("'{0}' : '{1}'".format(user, username))
            if user == username:
                ignore = True
        if ignore:
            return True
        else:
            return False

    @unicode_compact
    def addignore(self, comment):
        global ignored
        logger.info("Add Ignore")
        logger.info(ignored)
        username = self._client.find_user_by_id(self._get_user_id())
        logger.info("The username is '{0}'".format(username))
        ignore = False
        ignored.append(username)
        for user in ignored:
            logger.info("'{0}' : '{1}'".format(user, username))
            if user == username:
                ignore = True
        if ignore:
            return True
        else:
            return False

    @unicode_compact
    def stopignore(self, comment):
        global ignored
        print "Stop Ignore"
        username = self._client.find_user_by_id(self._get_user_id())
        print "The username is '{0}'".format(username)
        ignore = False
        for user in ignored:
            print "'{0}' : '{1}'".format(user, username)
            if user == username:
                ignored.remove(user)
                ignore = False  
        if ignore:
            return False
        else:
            return True

    def react(self, emojiname):
        self._client.react_to_message(
            emojiname=emojiname,
            channel=self._body['channel'],
            timestamp=self._body['ts'])

    @property
    def channel(self):
        return self._client.get_channel(self._body['channel'])

    @property
    def body(self):
        return self._body

    def docs_reply(self):
        reply = [u'    • `{0}` {1}'.format(v.__name__, v.__doc__ or '')
                 for _, v in
                 six.iteritems(self._plugins.commands['respond_to'])]
        return u'\n'.join(reply)
