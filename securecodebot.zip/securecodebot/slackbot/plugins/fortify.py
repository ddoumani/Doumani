from slackbot.bot import respond_to
from slackbot.bot import listen_to
import re
import json
import urllib2
import urllib
from urllib import quote
from base64 import b64encode
import logging

logger = logging.getLogger(__name__)

@respond_to('(?=.*\\bfortify\\b)(?=.*\\blicense\\b)(?=.*\\bneed\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\bfortify\\b)(?=.*\\blicense\\b)(?=.*\\bneed\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\bfortify\\b)(?=.*\\blicense\\b)(?=.*\\bwhere\\b).*', re.IGNORECASE)
@respond_to('(?=.*\\bfortify\\b)(?=.*\\blicense\\b)(?=.*\\bwhere\\b).*', re.IGNORECASE)
@respond_to('(?=.*\\bfortifyscan\\b)(?=.*\\blicense\\b)(?=.*\\bneed\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\bfortifyscan\\b)(?=.*\\blicense\\b)(?=.*\\bneed\\b).*', re.IGNORECASE)
def requestLicense(message):
    message.reply("I have sent you the license in a DM")
    path = "/opt/securecodebot/fortify.license"
    fname = "fortify.license"
    user = "GETUSER"
    ignored = message.ignorecheck("Ignore")
    if ignored:
        logger.info("User is ignored")
    else:
        message.sendFileDM(user, path, fname, "Here is your Fortify License. If you need anything additional don't hesitate to ask!")


@listen_to('!give license to (.*)', re.IGNORECASE)
@respond_to('!give license to (.*)', re.IGNORECASE)
def giveLicense(message, user):
    message.reply("Giving a license to {} in a DM".format(user))
    path = "/opt/securecodebot/fortify.license"
    fname = "fortify.license"
    message.sendFileDM(user, path, fname, "Here is your Fortify License. If you need anything additional don't hesitate to ask!")


@listen_to('!give SCA (.*) to (.*)', re.IGNORECASE)
@respond_to('!give SCA (.*) to (.*)', re.IGNORECASE)
def giveSca(message, version, user):
    attachment = {}
    attachment["fallback"] = "Fortify Installer"
    attachment["pretext"] = "This is the package you need to install the Fortify SCA tools."
    attachment["title"] = "SCA version {0}".format(version)
    if version.strip() == "16.10_Linux":
        attachment["title_link"] = "https://s3-us-west-2.amazonaws.com/nike-fortify-installers/16.10/HPE_Security_Fortify_SCA_and_Apps_16.10_Linux.tar.gz"
    elif version.strip() == "16.10_Mac":
        attachment["title_link"] = "https://s3-us-west-2.amazonaws.com/nike-fortify-installers/16.10/HPE_Security_Fortify_SCA_and_Apps_16.10_Mac.tar.gz"
    elif version.strip() == "16.10_Win":
        attachment["title_link"] = "https://s3-us-west-2.amazonaws.com/nike-fortify-installers/16.10/HPE_Security_Fortify_SCA_and_Apps_16.10_Windows.zip"
    attachment["text"] = "You will also need a license. You can request one by typing `I need a fortify license.`"
    attachment["color"] = "#7CD197"
    atl = []
    atl.append(attachment)
    if "title_link" in attachment:
        message.send_webapi("Here you go @{0}".format(user), atl)
    else:
        message.reply("I could not find SCA package {0}".format(version))


@respond_to('create ssc project (.*) with users (.*)', re.IGNORECASE)
def create_ssc_project(message, project_name, user_names):
    message.reply('I will try to create {0} for you.'.format(project_name))
    users_list = ["securecode_api", "jtrip2", "mharlo"]
    if "," in user_names:
        users = user_names.split(",")
        for u in users:
            users_list.append(u.strip())
    else:
        users_list.append(user_names.strip())
    data = {"projectName": project_name, "projectVersion": "1", "users": json.dumps({"users": users_list})}
    headers = {"X-SecureCode-API-Key": "02907f06bda14250bfa6f4b39667fb1f", "X-SecureCode-API-Secret": "5df9af5381dee53db04562b53ab0934ba4e6c3e9fad07df6"}
    url = "{apiurl}{endpoint}".format(apiurl="https://api-securecode.nike.com/api/v1/", endpoint="create_project")
    message.reply("Please wait, this can take up to 2 minutes...")
    req = urllib2.Request("{url}".format(url=url), headers=headers, data=urllib.urlencode(data))
    try:
        r = urllib2.urlopen(req)
    except urllib2.HTTPError as e:
        print_error = "{code} - {reason}".format(code=e.code, reason=e)
        for l in e.read().splitlines():
            print_error += "\n{line}".format(line=l)
        raise Exception(print_error)
    try:
        result = json.loads(r.read())
        print result
    except:
        print_error = "Unable to create project - did not get JSON response from API\nstdout:\n{stdout}".format(stdout=r.read())
        message.reply("Unable to create project")
        raise Exception(print_error)
    if result.get("result") == "fail" and result.get("stdout") and "duplicate name" in json.loads(result.get("stdout")).get("message"):
        message.reply("That project already exists.")
        return True  # our version already exists
    elif result.get("result") == "success" and result.get("stdout") and "duplicate name" in json.loads(result.get("stdout")).get("message"):
        message.reply("The project {} already exists".format(project_name))
        return True
    elif result.get("result") == "fail":
        print_error = "Failed to create project\nstdout:\n{stdout}".format(stdout=result)
        message.reply("Unable to create project")
        raise Exception(print_error)
    if r.getcode() in range(200, 299):
        message.reply("Created version '1' in project '{project}'".format(project=project_name))
        return True  # Project creation was successful
    else:
        print_error = "Failed to create project\nstdout:\n{stdout}".format(stdout=result)
        raise Exception(print_error)


@respond_to('update users for project (.*) (.*)', re.IGNORECASE)
def updateUsers(message, project_name, user_names):
    project_name = project_name.strip()
    message.react("working")
    message.reply('I will try to update users on {0} for you.'.format(project_name))
    users_list = ["securecode_api", "jtrip2", "mharlo"]
    if "," in user_names:
        users = user_names.split(",")
        for u in users:
            users_list.append(u.strip())
    else:
        users_list.append(user_names.strip())
    """"Gets the ID of the given project."""
    # This function went under an extreme overhaul which resulted in a significant performance improvement
    token = "ca0796b7-3dac-4f96-a086-4ae09451a128"
    token = b64encode(token)
    message.reply("Searching for project...")
    endpoint = "/api/v1/projects/"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    SSC_URL = "https://securecode.nike.com/ssc"
    headers["Authorization"] = "FortifyToken {0}".format(token)
    query = '?q=name:{project_name}'.format(project_name=quote(project_name))
    req = urllib2.Request("{url}{endpoint}{query}".format(url=SSC_URL, endpoint=endpoint, query=query), headers=headers)
    try:
        r = urllib2.urlopen(req)
        response = json.loads(r.read())
    except urllib2.HTTPError as e:
        print "Urllib2 error!"
        print "{code} - {reason}".format(code=e.code, reason=e.reason)
        for l in e.read().splitlines():
            print l
            response = None
    if response and response.get("responseCode") in range(200, 299):
        data = response["data"]
        if data:
            project_id = data[0].get("id")
            message.reply("I have found the project you specified. Hang in there while I adjust the access list.")
            print "Returning ID for project {p}".format(p=data[0].get("name"))
            #message.send("Getting User Ids. . .")
            #user_ids = get_user_ids(user_names)
            endpoint = "/api/v1/projects/{project_id}/versions".format(project_id=project_id)
            req = urllib2.Request("{url}{endpoint}".format(url=SSC_URL, endpoint=endpoint), headers=headers)
            try:
                r = urllib2.urlopen(req)
                response = json.loads(r.read())
            except urllib2.HTTPError as e:
                print "Urllib2 error!"
                print "{code} - {reason}".format(code=e.code, reason=e.reason)
                for l in e.read().splitlines():
                    print l

            data = response.get("data")

            current_users = []

            for d in data:
                if d.get("id"):
                    #message.send("Getting current user list from project version {0}...".format(d.get("name")))
                    req = urllib2.Request("{url}/api/v1/projectVersions/{id}/authEntities".format(url=SSC_URL, id=d.get("id")), headers=headers)
                    r = urllib2.urlopen(req)
                    response = json.loads(r.read())
                    auth_entities = response.get("data")
                    print json.dumps(auth_entities, indent=4, separators=(",", ": "))
                    for a in auth_entities:
                        if a.get("entityName"):
                            current_users.append(a.get("entityName"))
                        else:
                            print "Couldn't get an entityName for {0}".format(d.get("name"))

            current_users = list(set(current_users))

            #message.send("Current users in project {0}:".format(project_name))
            # for u in current_users:
            #     message.send("`{0}`".format(u))

            print "Updating users in project '{0}'".format(project_name)

            for user in current_users:
                if user not in users_list:
                    users_list.append(user)

            #message.send("New users list is: ")
            userIds = get_user_ids(list(set(users_list)))
            # for u in userIds:
            #     message.send("`{0}`".format(u.get("displayName")))

            for d in data:
                if d.get("id"):
                    payload = {"requests": [{"uri": "{url}/api/v1/projectVersions/{id}/authEntities".format(url=SSC_URL, id=d.get("id")),
                                             "httpVerb": "PUT",
                                             "postData": userIds}]}
                    endpoint = "/api/v1/bulk"
                    req = urllib2.Request("{url}{endpoint}".format(url=SSC_URL, endpoint=endpoint), headers=headers, data=str(json.dumps(payload)))
                    try:
                        r = urllib2.urlopen(req)
                    except urllib2.HTTPError as e:
                        print "Urllib2 error!"
                        print "{code} - {reason}".format(code=e.code, reason=e.reason)
                        for l in e.read().splitlines():
                            print l
                    print r.read()
                else:
                    print "Couldn't get project ID from JSON response!"

            message.reply("Your access request is now complete. :beer: I have sent you a DM with the updated user list.")
            #message.send_userDM_webapi("Updated access list for {0}", project_name)
            msgcontent = "```"
            for u in userIds:
                msgcontent += "{0}\n".format(u.get("displayName"))
            msgcontent += "```"
            message.send_DM_webapi(msgcontent)
        else:
            message.reply("I was unable to find the project you requested. Did you spell it right?")
            return None
    else:
        message.reply("I got an unusual response from the SSC. Please try again later.")
        print "Unexpected HTTP response code: {code}".format(code=json.dumps(response, indent=4, separators=(",", ": ")))


@listen_to('(?=.*\\bwhere\\b)(?=.*\\bget\\b)(?=.*\\btoken\\b).*', re.IGNORECASE)
@listen_to('token please', re.IGNORECASE)
@respond_to('token please', re.IGNORECASE)
@respond_to('(?=.*\\bneed\\b)(?=.*\\btoken\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\bneed\\b)(?=.*\\btoken\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\bget\\b)(?=.*\\bssctoken\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\bget\\b)(?=.*\\bssc\\b)(?=.*\\btoken\\b).*', re.IGNORECASE)
def requestToken(message):
    ignored = message.ignorecheck("Ignore")
    if ignored:
        logger.info("User is ignored")
    else:
        logger.info("User is not ignored")
        message.react("coin")
        message.reply('1 token coming up')
        message.send('I have generated a token and sent it to you in a DM.')
        message.send_DM_webapi('Here is your new shiny token!\n `ca0796b7-3dac-4f96-a086-4ae09451a128`')


@listen_to('!give token to (.*)', re.IGNORECASE)
def giveUserToken(message, user):
    message.react("coin")
    message.reply('1 token comming up')
    message.send('I have generated a token and sent it to {0} in a DM.'.format(user))
    message.send_userDM_webapi('Here is your new shiny token!\n `ca0796b7-3dac-4f96-a086-4ae09451a128`', user)


# @listen_to('(?=.*\\brequest\\b)(?=.*\\baccess\\b).*', re.IGNORECASE)
# @listen_to('(?=.*\\bneed\\b)(?=.*\\baccess\\b).*', re.IGNORECASE)
# @listen_to('(?=.*\\bgive\\b)(?=.*\\baccess\\b).*', re.IGNORECASE)
# def projectAccess(message):
#     message.reply_webapi('Sounds like you need to get access to a project.')


@listen_to('(?=.*\\bcreated\\b)(?=.*\\bproject\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\bcreate\\b)(?=.*\\bproject\\b).*', re.IGNORECASE)
def projectRequest(message):
    ignored = message.ignorecheck("Ignore")
    if ignored:
        logger.info("User is ignored")
    else:
        message.reply_webapi('It sounds like you need to create a new project on the SSC.\nIf you do, please send me a DM with the command `create ssc project <project_name> <your_user_id>`')


@listen_to('(?=.*\\bscan\\b)(?=.*\\blong\\b)(?=.*\\btime\\b).*', re.IGNORECASE)
def scanTime(message):
    ignored = message.ignorecheck("Ignore")
    if ignored:
        logger.info("User is ignored")
    else:
        message.reply_webapi('Sounds like your scan is taking a long time to run. Let me check on that for you!')


def get_user_ids(users):
    """Gets the SSC user IDs for a list of users."""
    token = "24e445c8-4efe-4b5b-a196-07fcbf66d551"
    token = b64encode(token)
    endpoint = "/api/v1/authEntities/?start=0&limit=-1"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    SSC_URL = "https://securecode.nike.com/ssc"
    headers["Authorization"] = "FortifyToken {0}".format(token)
    req = urllib2.Request("{url}{endpoint}".format(url=SSC_URL, endpoint=endpoint), headers=headers)
    try:
        r = urllib2.urlopen(req)
    except urllib2.HTTPError as e:
        print "Urllib2 error!"
        print "{code} - {reason}".format(code=e.code, reason=e.reason)
        for l in e.read().splitlines():
            print l
    response = json.loads(r.read())
    data = response.get("data")

    user_ids = []
    for user in users:
        print "Getting user ID for: {0}".format(user)
        try:
            user_data = (d for d in data if d.get("entityName") and d.get("entityName") == user).next()
        except StopIteration:
            print "User ID for user {user} not found!".format(user=user)
            continue
        user_id = user_data["id"]
        is_ldap = user_data["isLdap"]
        displayName = user_data["displayName"]
        user_obj = {"id": user_id, "isLdap": is_ldap, "displayName": displayName}
        user_ids.append(user_obj)
        print "Got user ID for user: {0}".format(user_obj["displayName"])
    return user_ids
