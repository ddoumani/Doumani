import re
from slackbot.bot import respond_to
from slackbot.bot import listen_to
import logging

logger = logging.getLogger(__name__)


@listen_to('(?=.*\\bhow\\b)(?=.*\\bconfigure\\b)(?=.*\\bjenkins\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\bhow\\b)(?=.*\\bsetup\\b)(?=.*\\bjenkins\\b).*', re.IGNORECASE)
@listen_to("How do i configure jenkins", re.IGNORECASE)
@listen_to('!Fortify jenkins integration', re.IGNORECASE)
@respond_to('!Fortify jenkins integration', re.IGNORECASE)
def configureJenkins(message):
	ignored = message.ignorecheck("Ignore")
	if ignored:
		logger.info("User is ignored")
	else:
		message.reply("Here is how you configure jenkins:")
		message.send_webapi("Step 1: Add a build step -> Select `Execute Shell`")
		message.send_webapi("Step 2: Add the following code to your new build step:")
		message.send_webapi("""```
# These are environment variables and can be either configured here in this script,
# or in the standard environment variables config in Jenkins.
BUILD_NAME=${JOB_NAME##*/}
SSC_PROJECT_NAME=
SSC_VERSION_NAME=
FORTIFY_AUTH_TOKEN=

# The full path to which to output the reports, minus the file extension (will generate both XML and PDF by default)
REPORT_FILENAME="${WORKSPACE}/fortify_report"

# Only required if you're running a Sonatype scan
SONATYPE_REPORT_FILENAME="${WORKSPACE}/sonatype_report.pdf"
   
fortifyupdate --acceptKey -url https://securecode.nike.com/ssc
if [ -d fortifytools ];
then
rm -rf fortifytools;
fi;

git clone http://bitbucket.nike.com/scm/sce/fortifytools.git

python fortifytools/fortify.py \\
-source "${WORKSPACE}" \\
-exclude \\
-build "${BUILD_NAME}" \\
-memory 8 \\
-upload \\
-wait \\
-cloudscan http://cloudscan-securecode.nike.com/cloud-ctrl \\
-sscurl https://securecode.nike.com/ssc \\
-sscproject "${SSC_PROJECT_NAME}" \\
-sscversion "${SSC_VERSION_NAME}" \\
-uptoken ${FORTIFY_AUTH_TOKEN} \\
-cloudtoken ${FORTIFY_AUTH_TOKEN} \\
-autocreate \\
-autocreate_users jtrip2,mharlo \\
-jvm 1.8 \\
-report \\
-report_filename "${REPORT_FILENAME}" \\
-sonatype_report "${SONATYPE_REPORT_FILENAME}"
```""")
		message.send_webapi("STEP 3: Thats It! You are done! Call it a day - You work hard! :beer: ")
