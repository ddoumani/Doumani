import re
from slackbot.bot import respond_to
from slackbot.bot import listen_to
import logging

logger = logging.getLogger(__name__)


@listen_to('I need to escalate')
def getDirector(message):
    muser = u'<@{}>'.format(message._get_user_id_2("msessions"))
    message.send('I will get the director for you. Adding {0}'.format(muser))


@listen_to('I am admin')
@respond_to('I am admin')
def adminCheck(message):
    message.adminCheck('admin')

@respond_to('Ignore Me', re.IGNORECASE)
def addIgnore(message):
    x = message.addignore("ignore")
    if x:
        message.reply("I no longer know you - You are dead to me.")
    else:
        message.reply("I refuse to not listen - Deal with it.")

@respond_to('Listen to me', re.IGNORECASE)
def stopIgnore(message):
    x = message.stopignore("ignore")
    if x:
        message.reply("I'm all ears - so to speak")
    else:
        message.reply("I still don't know you")    


@listen_to('I need a human', re.IGNORECASE)
def getHuman(message):
    message.reply("I will get someone for you")
    juser = u'<@{}>'.format(message._get_user_id_2("jason.tripp"))
    muser = u'<@{}>'.format(message._get_user_id_2("mharlo"))
    message.send("I need an adult {0} {1}".format(juser, muser))


@listen_to("^(I need help)?[ !?]*$", re.IGNORECASE)
@listen_to('^(Can someone help me)?[ !?]*$', re.IGNORECASE)
def help(message, something):
    # Message is replied to the sender (prefixed with @user)
    # Message is sent on the channel
    ignored = message.ignorecheck("Ignore")
    if ignored:
        logger.info("User is ignored")
    else:
        message.reply('What can I help you with:')
        message.send('You can say:\n```* I need a token\n* Create a new project\n* I need to report an issue\n* I need a human```')


@listen_to('(?=.*\\binvalid\\b)(?=.*\\btoken\\b).*', re.IGNORECASE)
@listen_to('(?=.*\\baccess\\b)(?=.*\\bdenied\\b).*', re.IGNORECASE)
def invalidToken(message):
    ignored = message.ignorecheck("Ignore")
    if ignored:
        logger.info("User is ignored")
    else:
        message.reply_webapi('Based on what you just said, I\'m pretty sure you need a new token.\nTo get one please type `I need a token`')


# @listen_to('(?=.*\\bfortify\\b)(?=.*\\bfailure\\b)(?=.*\\bhelp\\b).*', re.IGNORECASE)
# @listen_to('(?=.*\\bfortify\\b)(?=.*\\berror\\b)(?=.*\\bhelp\\b).*', re.IGNORECASE)
# @listen_to('Help with Fortify', re.IGNORECASE)
# def fortifyHelp(message):
#     message.reply("Based on what you just said, I'm pretty sure you need assistance with a Fortify error.")
#     message.reply_webapi('This function is still under construction.\nPlease visit https://securecode.nike.com/\n or type `I need a human`')
