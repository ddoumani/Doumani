Slackbot for SecureCode automation and triage.
==============================================

  The SecureCode team has designed this bot by wrapping easy to use listeners and responders around the Slack RTM API and WEB API.
  The RTM API allows the bot to respond quickly to events and the WEB API provides rich content, extensibility and meaningful responses ( including file distribution and DM )

  ## Features :
    - Real time messaging
    - Reply directly to user
    - Listen to channel for phrases, keywords, or your own regex
    - Send direct messages to users
    - Easy to add additional commands or functions using plugins
    - Web API support for sending attachments and rich text
    - File upload support
    - Error reporting to a support channel (configurable)

  | Plugin | Documentation |
  |-----------|---------------|
  | pleasent.py | Stuff for general conversation with users. |
  | fortify.py | Tools for supporting HP Fortify. |
  | help.py | Support for common erros and general assistance. |
  | docs.py | Support articles. |
  | upload.py | For uploading of course. |

  ## Running the bot :
  
  ### Using Docker (*Recommended*)
  
  1. Adjust the settings in slackbot/settings.py - Make sure to set the API_TOKEN.
  2. Add your plugins to the plugins directory.
  3. Run `docker build -t slackbot .`
  4. Run `docker run slackbot`
  
  ### Manual
  
  1. Run `pip install -r requirements.txt`
  2. Ensure your plugins are in the plugins directory
  3. Adjust the settings in slackbot/settings.py - Make sure to set the API_TOKEN.
  4. Run `python run.py` from the root directory of the repo